Figure source tables, analysis tables, and figure text alternatives.
Source CSV files use the original repository paths. See text_alternatives.md
for the conclusions conveyed by Figures 1–6. NDCG@10 refers to the top 10%.
