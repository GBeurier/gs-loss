Analysis and simulation code. Extract preserving directories. Install with
python -m pip install -e '.[dev]'. See README.md for commands and public data sources.
Full numerical outputs are in the repository; this ZIP contains no private data.
