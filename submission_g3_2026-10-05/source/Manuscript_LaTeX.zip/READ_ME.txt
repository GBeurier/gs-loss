Editable manuscript sources. Extract preserving paper/ and paper/g3/.
cd paper/g3; pdflatex main_g3; bibtex main_g3; pdflatex main_g3; pdflatex main_g3
Supplement: cd paper; pdflatex supplement; bibtex supplement; pdflatex supplement twice.
